#!/bin/sh

/koolshare/scripts/mia_config.sh &
